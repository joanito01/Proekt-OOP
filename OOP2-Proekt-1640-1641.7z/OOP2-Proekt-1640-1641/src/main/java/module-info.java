module org.example {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires spring.boot;
    requires spring.boot.autoconfigure;
    requires spring.context;
    requires spring.beans;
    requires spring.data.jpa;
    requires spring.core;
    requires spring.jdbc;
    requires java.persistence;
    requires org.hibernate.orm.core;
    requires org.apache.logging.log4j;
    requires org.apache.logging.log4j.core;
    requires org.apache.logging.log4j.slf4j;
    requires spring.data.commons;

    opens org.example to spring.core, spring.beans, spring.context;
    opens org.example.controllers to javafx.fxml, spring.core, spring.beans;
    opens org.example.entities to org.hibernate.orm.core, spring.core;
    opens org.example.services to spring.core;
    opens org.example.repositories to spring.core;


    exports org.example;
    exports org.example.controllers;
    exports org.example.entities;
    exports org.example.services;
    exports org.example.repositories;
}
