package org.example.repositories;

import org.example.entities.User;
import org.example.entities.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {
    List<Warehouse> findByOwner(User owner);

    @Query("SELECT w FROM Warehouse w WHERE w.id NOT IN (SELECT r.warehouse.id FROM RentalContract r WHERE r.startDate <= :endDate AND r.endDate >= :startDate)")
    List<Warehouse> findAvailableWarehouses(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}
