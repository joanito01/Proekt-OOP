package org.example.repositories;

import org.example.entities.RentalContract;
import org.example.entities.User;
import org.example.entities.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface RentalContractRepository extends JpaRepository<RentalContract, Long> {
    List<RentalContract> findByAgent(User agent);
    List<RentalContract> findByWarehouse(Warehouse warehouse);
    List<RentalContract> findByEndDateBefore(LocalDate currentDate);
    List<RentalContract> findByStartDateBetween(LocalDate startDate, LocalDate endDate);
}
