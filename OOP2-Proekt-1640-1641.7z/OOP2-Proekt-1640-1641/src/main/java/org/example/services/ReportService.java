package org.example.services;

import org.example.entities.RentalContract;
import org.example.repositories.RentalContractRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ReportService {

    @Autowired
    private RentalContractRepository rentalContractRepository;

    public List<RentalContract> getContractsInPeriod(LocalDate startDate, LocalDate endDate) {
        return rentalContractRepository.findByStartDateBetween(startDate, endDate);
    }
}
