package org.example.services;

import org.example.entities.Rating;
import org.example.entities.User;
import org.example.repositories.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RatingService {

    @Autowired
    private RatingRepository ratingRepository;

    public void createRating(User agent, int ratingValue, String comment) {
        Rating rating = new Rating();
        rating.setAgent(agent);
        rating.setRatingValue(ratingValue);
        rating.setComment(comment);
        ratingRepository.save(rating);
    }

    public Rating findRatingById(Long id) {
        return ratingRepository.findById(id).orElse(null);
    }

    public List<Rating> getAllRatings() {
        return ratingRepository.findAll();
    }

    public void updateRating(Rating rating) {
        ratingRepository.save(rating);
    }

    public void deleteRating(Long id) {
        ratingRepository.deleteById(id);
    }

    public List<Rating> getRatingsByAgent(User agent) {
        return ratingRepository.findByAgent(agent);
    }
}
