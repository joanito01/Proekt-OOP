package org.example.services;

import org.example.entities.RentalContract;
import org.example.entities.User;
import org.example.entities.Warehouse;
import org.example.repositories.RentalContractRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class RentalContractService {

    @Autowired
    private RentalContractRepository rentalContractRepository;

    public void createRentalContract(User agent, String tenantInfo, Double price, LocalDate startDate, LocalDate endDate, Warehouse warehouse) {
        RentalContract rentalContract = new RentalContract();
        rentalContract.setAgent(agent);
        rentalContract.setTenantInfo(tenantInfo);
        rentalContract.setPrice(price);
        rentalContract.setStartDate(startDate);
        rentalContract.setEndDate(endDate);
        rentalContract.setWarehouse(warehouse);
        rentalContractRepository.save(rentalContract);
    }

    public RentalContract findRentalContractById(Long id) {
        return rentalContractRepository.findById(id).orElse(null);
    }

    public List<RentalContract> getAllRentalContracts() {
        return rentalContractRepository.findAll();
    }

    public void updateRentalContract(RentalContract rentalContract) {
        rentalContractRepository.save(rentalContract);
    }

    public void deleteRentalContract(Long id) {
        rentalContractRepository.deleteById(id);
    }

    public List<RentalContract> getRentalContractsByAgent(User agent) {
        return rentalContractRepository.findByAgent(agent);
    }

    public List<RentalContract> getExpiringContracts(LocalDate currentDate) {
        return rentalContractRepository.findByEndDateBefore(currentDate);
    }
}
