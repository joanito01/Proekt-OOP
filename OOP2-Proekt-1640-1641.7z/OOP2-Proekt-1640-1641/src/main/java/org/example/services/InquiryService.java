package org.example.services;

import org.example.entities.RentalContract;
import org.example.entities.Room;
import org.example.entities.User;
import org.example.entities.Warehouse;
import org.example.repositories.RentalContractRepository;
import org.example.repositories.RoomRepository;
import org.example.repositories.WarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class InquiryService {

    @Autowired
    private WarehouseRepository warehouseRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private RentalContractRepository rentalContractRepository;

    public List<Warehouse> getAvailableWarehouses(LocalDate startDate, LocalDate endDate) {
        return warehouseRepository.findAvailableWarehouses(startDate, endDate);
    }

    public List<RentalContract> getContractsByWarehouse(Warehouse warehouse) {
        return rentalContractRepository.findByWarehouse(warehouse);
    }

    public Warehouse getWarehouseDetails(Long warehouseId) {
        return warehouseRepository.findById(warehouseId).orElse(null);
    }

    public List<Warehouse> getWarehousesByOwner(User owner) {
        return warehouseRepository.findByOwner(owner);
    }

    public List<RentalContract> getExpiringContracts(LocalDate currentDate) {
        return rentalContractRepository.findByEndDateBefore(currentDate);
    }

    public List<Room> getRoomsByWarehouse(Warehouse warehouse) {
        return roomRepository.findByWarehouse(warehouse);
    }

    public RentalContract getContractDetails(Long contractId) {
        return rentalContractRepository.findById(contractId).orElse(null);
    }
}
