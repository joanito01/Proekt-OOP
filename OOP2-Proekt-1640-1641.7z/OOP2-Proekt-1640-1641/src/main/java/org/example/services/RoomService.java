package org.example.services;

import org.example.entities.Room;
import org.example.entities.Warehouse;
import org.example.repositories.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    public void createRoom(Warehouse warehouse, String dimensions, String climaticConditions, String typeOfGoods) {
        Room room = new Room();
        room.setWarehouse(warehouse);
        room.setDimensions(dimensions);
        room.setClimaticConditions(climaticConditions);
        room.setTypeOfGoods(typeOfGoods);
        roomRepository.save(room);
    }

    public Room findRoomById(Long id) {
        return roomRepository.findById(id).orElse(null);
    }

    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    public void updateRoom(Room room) {
        roomRepository.save(room);
    }

    public void deleteRoom(Long id) {
        roomRepository.deleteById(id);
    }

    public List<Room> getRoomsByWarehouse(Warehouse warehouse) {
        return roomRepository.findByWarehouse(warehouse);
    }
}
