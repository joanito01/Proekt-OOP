package org.example.services;

import org.example.entities.Warehouse;
import org.example.entities.User;
import org.example.repositories.WarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class WarehouseService {

    @Autowired
    private WarehouseRepository warehouseRepository;

    public void createWarehouse(User owner, String address, String category) {
        Warehouse warehouse = new Warehouse();
        warehouse.setOwner(owner);
        warehouse.setAddress(address);
        warehouse.setCategory(category);
        warehouseRepository.save(warehouse);
    }

    public Warehouse findWarehouseById(Long id) {
        return warehouseRepository.findById(id).orElse(null);
    }

    public List<Warehouse> getAllWarehouses() {
        return warehouseRepository.findAll();
    }

    public void updateWarehouse(Warehouse warehouse) {
        warehouseRepository.save(warehouse);
    }

    public void deleteWarehouse(Long id) {
        warehouseRepository.deleteById(id);
    }

    public List<Warehouse> getWarehousesByOwner(User owner) {
        return warehouseRepository.findByOwner(owner);
    }
}
