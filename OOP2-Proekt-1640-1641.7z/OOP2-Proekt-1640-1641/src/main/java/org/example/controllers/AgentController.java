package org.example.controllers;

import org.example.SpringFXMLLoader;
import org.example.entities.User;
import org.example.entities.RentalContract;
import org.example.entities.Notification;
import org.example.entities.Warehouse;
import org.example.services.RentalContractService;
import org.example.services.NotificationService;
import org.example.services.InquiryService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.time.LocalDate;
import java.util.List;

@Controller
public class AgentController {

    @Autowired
    private RentalContractService rentalContractService;

    @Autowired
    private SpringFXMLLoader fxmlLoader;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private InquiryService inquiryService;

    private User agent;

    @FXML
    private TextField tenantInfoField;

    @FXML
    private TextField priceField;

    @FXML
    private DatePicker startDatePicker;

    @FXML
    private DatePicker endDatePicker;

    @FXML
    private DatePicker inquiryStartDatePicker;

    @FXML
    private DatePicker inquiryEndDatePicker;

    @FXML
    private Button createRentalContractButton;

    @FXML
    private Button viewAvailableWarehousesButton;

    @FXML
    private Button viewExpiringContractsButton;

    @FXML
    private ListView<RentalContract> rentalContractList;

    @FXML
    private ListView<Notification> notificationList;

    @FXML
    private ListView<Warehouse> availableWarehouseList;

    @FXML
    private ListView<RentalContract> expiringContractList;

    public void setAgent(User agent) {
        this.agent = agent;
        loadRentalContracts();
        loadNotifications();
    }

    @FXML
    public void handleCreateRentalContract() {
        String tenantInfo = tenantInfoField.getText();
        String priceString = priceField.getText(); // Declare and initialize priceString
        Double price = Double.parseDouble(priceString); // Convert priceString to Double
        LocalDate startDate = startDatePicker.getValue();
        LocalDate endDate = endDatePicker.getValue();
        Warehouse warehouse = null;
        rentalContractService.createRentalContract(agent, tenantInfo, price, startDate, endDate, warehouse);
        loadRentalContracts();
        clearForm();
    }

    @FXML
    public void handleViewAvailableWarehouses() {
        LocalDate startDate = inquiryStartDatePicker.getValue();
        LocalDate endDate = inquiryEndDatePicker.getValue();
        List<Warehouse> warehouses = inquiryService.getAvailableWarehouses(startDate, endDate);
        availableWarehouseList.setItems(FXCollections.observableArrayList(warehouses));
    }

    @FXML
    public void handleViewExpiringContracts() {
        LocalDate currentDate = LocalDate.now();
        List<RentalContract> contracts = inquiryService.getExpiringContracts(currentDate);
        expiringContractList.setItems(FXCollections.observableArrayList(contracts));
    }

    private void loadRentalContracts() {
        rentalContractList.setItems(FXCollections.observableArrayList(rentalContractService.getRentalContractsByAgent(agent)));
    }

    private void loadNotifications() {
        notificationList.setItems(FXCollections.observableArrayList(notificationService.getNotificationsByUser(agent)));
    }

    private void clearForm() {
        tenantInfoField.clear();
        priceField.clear();
        startDatePicker.setValue(null);
        endDatePicker.setValue(null);
    }
}
