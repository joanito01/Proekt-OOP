package org.example.controllers;

import org.example.SpringFXMLLoader;
import org.example.entities.Notification;
import org.example.entities.User;
import org.example.services.NotificationService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private SpringFXMLLoader fxmlLoader;

    @FXML
    private ListView<Notification> notificationList;

    private User currentUser;

    public void setCurrentUser(User user) {
        this.currentUser = user;
        loadNotifications();
    }

    private void loadNotifications() {
        List<Notification> notifications = notificationService.getNotificationsByUser(currentUser);
        notificationList.setItems(FXCollections.observableArrayList(notifications));
    }
}
