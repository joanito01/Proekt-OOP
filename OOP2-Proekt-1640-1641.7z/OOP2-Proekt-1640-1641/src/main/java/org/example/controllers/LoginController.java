package org.example.controllers;

import org.example.SpringFXMLLoader;
import org.example.entities.User;
import org.example.services.UserService;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    @Autowired
    private SpringFXMLLoader fxmlLoader;

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        User user = userService.authenticate(username, password);

        if (user != null) {
            loadDashboard(user);
        } else {
            showAlert("Login Failed", "Invalid username or password");
        }
    }

    private void loadDashboard(User user) {
        try {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            Parent root = null;

            if ("ADMIN".equals(user.getRole())) {
                root = fxmlLoader.load("/fxml/admin_dashboard.fxml");
            } else if ("OWNER".equals(user.getRole())) {
                root = fxmlLoader.load("/fxml/owner_dashboard.fxml");
            } else if ("AGENT".equals(user.getRole())) {
                root = fxmlLoader.load("/fxml/agent_dashboard.fxml");
            } else {
                showAlert("Error", "Unauthorized user role");
                return;
            }

            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Unable to load dashboard");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
