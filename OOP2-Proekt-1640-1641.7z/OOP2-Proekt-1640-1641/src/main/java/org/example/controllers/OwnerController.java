package org.example.controllers;

import javafx.scene.control.Alert;
import org.example.SpringFXMLLoader;
import org.example.entities.User;
import org.example.entities.Room;
import org.example.entities.RentalContract;
import org.example.entities.Warehouse;
import org.example.services.InquiryService;
import org.example.services.WarehouseService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class OwnerController {

    @Autowired
    private WarehouseService warehouseService;

    @Autowired
    private InquiryService inquiryService;

    @Autowired
    private SpringFXMLLoader fxmlLoader;

    private User owner;

    @FXML
    private TextField addressField;

    @FXML
    private TextField categoryField;

    @FXML
    private ListView<Warehouse> warehouseList;

    @FXML
    private ListView<Room> roomList;

    @FXML
    private TextField warehouseIdField;

    @FXML
    private Button createWarehouseButton;

    @FXML
    public void initialize() {
        loadWarehouses();
    }

    public void setOwner(User owner) {
        this.owner = owner;
        loadWarehouses();
    }

    @FXML
    public void handleCreateWarehouse() {
        String address = addressField.getText();
        String category = categoryField.getText();
        warehouseService.createWarehouse(owner, address, category);
        loadWarehouses();
        clearWarehouseForm();
    }

    @FXML
    public void handleGenerateContractReport() {
        try {
            Long warehouseId = Long.parseLong(warehouseIdField.getText());
            Warehouse warehouse = inquiryService.getWarehouseDetails(warehouseId);
            List<RentalContract> contracts = inquiryService.getContractsByWarehouse(warehouse);

            // Display the report (you can customize this as needed)
            StringBuilder report = new StringBuilder();
            report.append("Contracts for Warehouse ID: ").append(warehouseId).append("\n");
            for (RentalContract contract : contracts) {
                report.append(contract.toString()).append("\n");
            }

            showAlert("Contract Report", report.toString());
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid Warehouse ID");
        } catch (Exception e) {
            showAlert("Error", "Unable to generate report: " + e.getMessage());
        }
    }

    private void loadWarehouses() {
        warehouseList.setItems(FXCollections.observableArrayList(warehouseService.getWarehousesByOwner(owner)));
    }

    private void clearWarehouseForm() {
        addressField.clear();
        categoryField.clear();
    }

    @FXML
    public void handleViewRooms() {
        Warehouse warehouse = warehouseList.getSelectionModel().getSelectedItem();
        if (warehouse != null) {
            List<Room> rooms = inquiryService.getRoomsByWarehouse(warehouse);
            roomList.setItems(FXCollections.observableArrayList(rooms));
        } else {
            showAlert("Error", "No warehouse selected");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
