package org.example.controllers;

import org.example.SpringFXMLLoader;
import org.example.entities.User;
import org.example.services.UserService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private SpringFXMLLoader fxmlLoader;

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button createUserButton;

    @FXML
    private ListView<User> userList;

    @FXML
    public void initialize() {
        loadUsers();
    }

    @FXML
    public void handleCreateUser() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        userService.createUser(username, password, "USER");  // Assuming default role as USER
        loadUsers();
        clearForm();
    }

    private void loadUsers() {
        userList.setItems(FXCollections.observableArrayList(userService.getAllUsers()));
    }

    private void clearForm() {
        usernameField.clear();
        passwordField.clear();
    }
}
