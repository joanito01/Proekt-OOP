package org.example.controllers;

import org.example.SpringFXMLLoader;
import org.example.entities.User;
import org.example.services.UserService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private SpringFXMLLoader fxmlLoader;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField passwordField;

    @FXML
    private ComboBox<String> roleComboBox;

    @FXML
    private Button createUserButton;

    @FXML
    private ListView<User> userList;

    @FXML
    public void initialize() {
        roleComboBox.setItems(FXCollections.observableArrayList("ADMIN", "OWNER", "AGENT"));
        loadUsers();
    }

    @FXML
    public void handleCreateUser() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String role = roleComboBox.getValue();
        userService.createUser(username, password, role);
        loadUsers();
        clearForm();
    }

    private void loadUsers() {
        userList.setItems(FXCollections.observableArrayList(userService.getAllUsers()));
    }

    private void clearForm() {
        usernameField.clear();
        passwordField.clear();
        roleComboBox.getSelectionModel().clearSelection();
    }
}
